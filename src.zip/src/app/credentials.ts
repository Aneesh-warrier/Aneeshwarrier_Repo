export const firebaseConfig = {
  apiKey: "AIzaSyCPW6Wobiec-YjO5fjHQgtxB5HofYG3aTE",
  authDomain: "webdestiny-cc208.firebaseapp.com",
  databaseURL: "https://webdestiny-cc208.firebaseio.com",
  projectId: "webdestiny-cc208",
  storageBucket: "webdestiny-cc208.appspot.com",
  messagingSenderId: "188397433723"
  };